// src/pages/ProfileDetails.jsx

function ProfileDetails() {
  return <div>Profile Details</div>;
}

export default ProfileDetails;
