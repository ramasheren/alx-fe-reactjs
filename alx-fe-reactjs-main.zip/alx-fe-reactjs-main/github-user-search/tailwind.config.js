// tailwind.config.js

export default {
  content: [
    './src/**/*.{html,js,jsx}', // This ensures Tailwind looks at your JSX files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
