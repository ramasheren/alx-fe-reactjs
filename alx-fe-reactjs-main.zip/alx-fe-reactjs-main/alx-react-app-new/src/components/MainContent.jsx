const MainContent = () => {
  return (
    <main style={{ padding: '20px', backgroundColor: '#f0f0f0', textAlign: 'center' }}>
      <p>I love to visit New York, Paris, and Tokyo.</p>
    </main>
  );
};

export default MainContent;
