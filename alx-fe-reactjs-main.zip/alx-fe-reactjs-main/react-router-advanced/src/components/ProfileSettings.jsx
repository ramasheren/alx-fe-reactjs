// src/pages/ProfileSettings.jsx

function ProfileSettings() {
  return <div>Profile Settings</div>;
}

export default ProfileSettings;
