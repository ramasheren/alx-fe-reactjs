import RegistrationForm from "./RegistrationForm";
import FormikForm from "./FormikForm";
function App() {
  return (
    <>
      <RegistrationForm />
      <FormikForm />
    </>
  );
}

export default App;
